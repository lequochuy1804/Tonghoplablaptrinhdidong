package com.example.lequochuy_1150070016;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String[] units = {
            "USD", "EUR", "GBP", "INR",
            "AUD", "CAD", "ZAR", "NZD",
            "JPY", "VND"
    };

    private int[] flagRes = {
            R.drawable.flag_us,
            R.drawable.flag_eur,
            R.drawable.flag_gbp,
            R.drawable.flag_inr,
            R.drawable.flag_aud,
            R.drawable.flag_cad,
            R.drawable.flag_us,
            R.drawable.flag_us,
            R.drawable.flag_us,
            R.drawable.vn_flag
    };

    private double[][] rate = {
            {1.0, 0.9, 0.8, 83, 1.5, 1.4, 19, 1.6, 150, 25000},
            {1.1, 1.0, 0.88, 90, 1.6, 1.5, 20, 1.7, 160, 27000},
            {1.25, 1.14, 1.0, 100, 1.8, 1.7, 22, 1.9, 180, 30000},
            {0.012, 0.011, 0.01, 1.0, 0.018, 0.017, 0.22, 0.019, 1.8, 300},
            {0.67, 0.62, 0.56, 55, 1.0, 0.95, 13, 1.1, 120, 19000},
            {0.7, 0.65, 0.59, 58, 1.05, 1.0, 13.5, 1.15, 125, 20000},
            {0.053, 0.05, 0.045, 4.5, 0.077, 0.074, 1.0, 0.085, 9, 1500},
            {0.63, 0.59, 0.53, 53, 0.95, 0.87, 12, 1.0, 110, 18000},
            {0.0067, 0.0062, 0.0056, 0.56, 0.0083, 0.008, 0.11, 0.009, 1.0, 160},
            {0.00004, 0.000037, 0.000033, 0.0033, 0.000053, 0.00005, 0.00067, 0.000055, 0.0063, 1.0}
    };

    private EditText edtAmount;
    private Spinner spnFrom, spnTo;
    private Button btnConvert;
    private TextView txtResult;
    private ImageView imgFrom, imgTo;
    private Button btnOpenLength, btnOpenLab7, btnOpenColor, btnOpenFoodList, btnOpenFoodGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtAmount = findViewById(R.id.edtAmount);
        spnFrom = findViewById(R.id.spnFrom);
        spnTo = findViewById(R.id.spnTo);
        btnConvert = findViewById(R.id.btnConvert);
        txtResult = findViewById(R.id.txtResult);
        imgFrom = findViewById(R.id.imgFrom);
        imgTo = findViewById(R.id.imgTo);
        btnOpenLength = findViewById(R.id.btnOpenLength);
        btnOpenLab7 = findViewById(R.id.btnOpenLab7);
        btnOpenColor = findViewById(R.id.btnOpenColor);
        btnOpenFoodList = findViewById(R.id.btnOpenFoodList);
        btnOpenFoodGrid = findViewById(R.id.btnOpenFoodGrid);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                units
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spnFrom.setAdapter(adapter);
        spnTo.setAdapter(adapter);

        spnFrom.setSelection(0);
        spnTo.setSelection(units.length - 1);

        setFlag(imgFrom, 0);
        setFlag(imgTo, units.length - 1);

        spnFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                setFlag(imgFrom, position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        spnTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                setFlag(imgTo, position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertMoney();
            }
        });

        btnOpenLength.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, LengthActivity.class);
                startActivity(i);
            }
        });

        btnOpenLab7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Lab7Activity.class);
                startActivity(i);
            }
        });

        btnOpenColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ColorActivity.class);
                startActivity(i);
            }
        });

        btnOpenFoodList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, FoodListActivity.class);
                startActivity(i);
            }
        });

        btnOpenFoodGrid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, FoodGridActivity.class);
                startActivity(i);
            }
        });
    }

    private void setFlag(ImageView img, int index) {
        int resId = flagRes[index];
        img.setImageResource(resId);
    }

    private void convertMoney() {
        String sAmount = edtAmount.getText().toString().trim();
        if (sAmount.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập số tiền", Toast.LENGTH_SHORT).show();
            return;
        }
        double amount = Double.parseDouble(sAmount);
        int fromIndex = spnFrom.getSelectedItemPosition();
        int toIndex = spnTo.getSelectedItemPosition();
        double result = amount * rate[fromIndex][toIndex];
        String unitTo = units[toIndex];
        txtResult.setText("Kết quả: " + result + " " + unitTo);
    }
}
