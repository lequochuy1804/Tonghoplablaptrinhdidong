package com.example.lequochuy_1150070016;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class LengthActivity extends AppCompatActivity {

    private EditText edtValue;
    private Spinner spnUnit;
    private ListView lvResult;

    private String[] unitNames;

    private double[] toKm = {
            1.852,
            1.609344,
            1.0,
            0.09144,
            0.001,
            0.0009144,
            0.0003048,
            0.0000254
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);
        setTitle(R.string.length_title);

        edtValue = findViewById(R.id.edtValue);
        spnUnit = findViewById(R.id.spnUnit);
        lvResult = findViewById(R.id.lvResult);

        unitNames = new String[]{
                getString(R.string.unit_sea_mile),
                getString(R.string.unit_mile),
                getString(R.string.unit_km),
                getString(R.string.unit_li),
                getString(R.string.unit_m),
                getString(R.string.unit_yd),
                getString(R.string.unit_ft),
                getString(R.string.unit_in)
        };

        ArrayAdapter<String> unitAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                unitNames
        );
        unitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnUnit.setAdapter(unitAdapter);

        spnUnit.setSelection(1);

        spnUnit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateList();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        edtValue.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                updateList();
            }
        });

        edtValue.setText("1.23");
        updateList();
    }

    private void updateList() {
        String s = edtValue.getText().toString().trim();
        if (s.isEmpty()) {
            lvResult.setAdapter(null);
            return;
        }

        double value;
        try {
            value = Double.parseDouble(s);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Giá trị không hợp lệ", Toast.LENGTH_SHORT).show();
            return;
        }

        int fromIndex = spnUnit.getSelectedItemPosition();
        double valueInKm = value * toKm[fromIndex];

        ArrayList<String> lines = new ArrayList<>();

        for (int i = 0; i < unitNames.length; i++) {
            double v = valueInKm / toKm[i];
            String line = String.format(Locale.US, "%.4f    %s", v, unitNames[i]);
            lines.add(line);
        }

        ArrayAdapter<String> resultAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                lines
        );
        lvResult.setAdapter(resultAdapter);
    }
}
