package com.example.lequochuy_1150070016;

public class Food {
    private int imageResId;
    private String name;
    private String description;

    public Food(int imageResId, String name, String description) {
        this.imageResId = imageResId;
        this.name = name;
        this.description = description;
    }

    public int getImageResId() {
        return imageResId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
}
